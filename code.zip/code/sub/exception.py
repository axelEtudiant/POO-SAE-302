"""

Contient toutes les exceptions utilisées

"""

